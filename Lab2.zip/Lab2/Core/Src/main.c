/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdint.h>
#include "stm32l4xx_hal_adc_ex.h"
#include "arm_math.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef enum { MODE_FIXED = 0, MODE_TEMP = 1 } mode_t;
typedef enum { W_TRI = 0, W_SAW = 1, W_SINE = 2 } wave_t;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define N_SAMPLES  64u
#define SAMPLE_US  8u
#define PI_F       3.14159265358979323846f
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

DAC_HandleTypeDef hdac1;

/* USER CODE BEGIN PV */
__attribute__((aligned(4))) volatile uint32_t triangle = 0;
__attribute__((aligned(4))) volatile uint32_t saw      = 0;
__attribute__((aligned(4))) volatile uint32_t sine = 0;

__attribute__((aligned(4))) volatile uint32_t adc_vref_raw = 0;
__attribute__((aligned(4))) volatile uint32_t adc_vts_raw  = 0;
__attribute__((aligned(4))) volatile uint32_t vref_mV      = 0;
__attribute__((aligned(4))) volatile int32_t  temp_C       = 0;

__attribute__((aligned(4))) volatile uint32_t dac_out   = 0;
__attribute__((aligned(4))) volatile mode_t   mode      = MODE_FIXED;
__attribute__((aligned(4))) volatile wave_t   fixed_wave= W_TRI;

static uint16_t sine_lut[N_SAMPLES];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DAC1_Init(void);
static void MX_ADC1_Init(void);
/* USER CODE BEGIN PFP */
static void DWT_Init(void);
static void DWT_Delay_us(uint32_t us);
static uint16_t tri_from_phase(uint32_t phase, uint32_t n_samples);
static void     BuildSineLUT(void);
static uint16_t sample_from_wave(wave_t w, uint32_t phase);

static uint32_t ADC1_ReadVrefint_Regular(void);
static uint32_t ADC1_ReadTemp_Injected(void);

static void HandleButton(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DAC1_Init();
  MX_ADC1_Init();
  /* USER CODE BEGIN 2 */
  DWT_Init();
  BuildSineLUT();


    /* Start DAC channels */
    HAL_DAC_Start(&hdac1, DAC_CHANNEL_1);
    //HAL_DAC_Start(&hdac1, DAC_CHANNEL_2); /*For part 2 */

    /* Calibrate ADC once */
    if (HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED) != HAL_OK)
    {
      Error_Handler();
    }

    /* Small settle time for internal channels */
    HAL_Delay(10);

    /* Waveform timing */
    uint32_t phase = 0;

    /* read ADC every 200ms without blocking the DAC loop */
    uint32_t last_adc_ms = HAL_GetTick();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  HandleButton();

	  /* poll Vrefint + Temp every ~200ms */
	  uint32_t now = HAL_GetTick();
	  if ((now - last_adc_ms) >= 200u)
	  {
	    last_adc_ms = now;

	    adc_vref_raw = ADC1_ReadVrefint_Regular();
	    adc_vts_raw  = ADC1_ReadTemp_Injected();

	    vref_mV = __HAL_ADC_CALC_VREFANALOG_VOLTAGE(adc_vref_raw, ADC_RESOLUTION_12B);
	    temp_C  = (int32_t)__HAL_ADC_CALC_TEMPERATURE(vref_mV, adc_vts_raw, ADC_RESOLUTION_12B);
	  }

	  triangle = tri_from_phase(phase, N_SAMPLES);
	  saw      = (phase * 4095u) / (N_SAMPLES - 1u);
	  sine     = sine_lut[phase];

	  /* DAC output selection */
	  wave_t w = (mode == MODE_FIXED) ? fixed_wave : W_SINE;

	  /* Temperature-dependent pitch:
	     phase_step increases with temp => higher frequency */
	  uint32_t phase_step = 1u;
	  if (mode == MODE_TEMP)
	  {
	    int32_t tC = temp_C;
	    if (tC < 0)  tC = 0;
	    if (tC > 60) tC = 60;
	    phase_step = 1u + (uint32_t)(tC / 15);   // 1..5
	  }

	  dac_out = sample_from_wave(w, phase);

	  /* Send output to DAC */
	  HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_1, DAC_ALIGN_12B_R, dac_out);
	  HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_12B_R, saw);

	  phase = (phase + phase_step) % N_SAMPLES;
	  DWT_Delay_us(SAMPLE_US);


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 60;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};
  ADC_InjectionConfTypeDef sConfigInjected = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Disable Injected Queue
  */
  HAL_ADCEx_DisableInjectedQueue(&hadc1);

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_VREFINT;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_247CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Injected Channel
  */
  sConfigInjected.InjectedChannel = ADC_CHANNEL_TEMPSENSOR;
  sConfigInjected.InjectedRank = ADC_INJECTED_RANK_1;
  sConfigInjected.InjectedSamplingTime = ADC_SAMPLETIME_247CYCLES_5;
  sConfigInjected.InjectedSingleDiff = ADC_SINGLE_ENDED;
  sConfigInjected.InjectedOffsetNumber = ADC_OFFSET_NONE;
  sConfigInjected.InjectedOffset = 0;
  sConfigInjected.InjectedNbrOfConversion = 1;
  sConfigInjected.InjectedDiscontinuousConvMode = DISABLE;
  sConfigInjected.AutoInjectedConv = DISABLE;
  sConfigInjected.QueueInjectedContext = DISABLE;
  sConfigInjected.ExternalTrigInjecConv = ADC_INJECTED_SOFTWARE_START;
  sConfigInjected.ExternalTrigInjecConvEdge = ADC_EXTERNALTRIGINJECCONV_EDGE_NONE;
  sConfigInjected.InjecOversamplingMode = DISABLE;
  if (HAL_ADCEx_InjectedConfigChannel(&hadc1, &sConfigInjected) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief DAC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_DAC1_Init(void)
{

  /* USER CODE BEGIN DAC1_Init 0 */

  /* USER CODE END DAC1_Init 0 */

  DAC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN DAC1_Init 1 */

  /* USER CODE END DAC1_Init 1 */

  /** DAC Initialization
  */
  hdac1.Instance = DAC1;
  if (HAL_DAC_Init(&hdac1) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT1 config
  */
  sConfig.DAC_SampleAndHold = DAC_SAMPLEANDHOLD_DISABLE;
  sConfig.DAC_Trigger = DAC_TRIGGER_NONE;
  sConfig.DAC_HighFrequency = DAC_HIGH_FREQUENCY_INTERFACE_MODE_ABOVE_80MHZ;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  sConfig.DAC_ConnectOnChipPeripheral = DAC_CHIPCONNECT_DISABLE;
  sConfig.DAC_UserTrimming = DAC_TRIMMING_FACTORY;
  if (HAL_DAC_ConfigChannel(&hdac1, &sConfig, DAC_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT2 config
  */
  if (HAL_DAC_ConfigChannel(&hdac1, &sConfig, DAC_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DAC1_Init 2 */

  /* USER CODE END DAC1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : BUTTON_Pin */
  GPIO_InitStruct.Pin = BUTTON_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(BUTTON_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LED_Pin */
  GPIO_InitStruct.Pin = LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

static void BuildSineLUT(void)
{
  for (uint32_t i = 0; i < N_SAMPLES; i++)
  {
    float theta = (2.0f * PI_F * (float)i) / (float)N_SAMPLES;  // 0..2pi
    float s = arm_sin_f32(theta);                               // -1..1
    float y = 0.5f * (s + 1.0f);                                // 0..1
    uint32_t v = (uint32_t)(y * 4095.0f + 0.5f);
    if (v > 4095u) v = 4095u;
    sine_lut[i] = (uint16_t)v;
  }
}

static uint16_t sample_from_wave(wave_t w, uint32_t phase)
{
  switch (w)
  {
    case W_TRI:  return tri_from_phase(phase, N_SAMPLES);
    case W_SAW:  return (uint16_t)((phase * 4095u) / (N_SAMPLES - 1u));
    default:     return sine_lut[phase];
  }
}

/* Polling + debounce + edge detect, pressed = GPIO_PIN_RESET. */
static void HandleButton(void)
{
  static GPIO_PinState last = GPIO_PIN_SET;
  static uint32_t last_ms = 0;

  GPIO_PinState now = HAL_GPIO_ReadPin(BUTTON_GPIO_Port, BUTTON_Pin);
  uint32_t t = HAL_GetTick();

  if ((last == GPIO_PIN_SET) && (now == GPIO_PIN_RESET) && ((t - last_ms) > 200u))
  {
    last_ms = t;

    if (mode == MODE_FIXED)
    {
      mode = MODE_TEMP;
      HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_SET);   // LED ON
    }
    else
    {
      mode = MODE_FIXED;
      HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET); // LED OFF
      fixed_wave = (wave_t)((fixed_wave + 1u) % 3u);             // TRI->SAW->SINE
    }
  }

  last = now;
}

static uint32_t ADC1_ReadVrefint_Regular(void)
{
  if (HAL_ADC_Start(&hadc1) != HAL_OK) { Error_Handler(); }
  if (HAL_ADC_PollForConversion(&hadc1, 10) != HAL_OK) { Error_Handler(); }

  uint32_t val = HAL_ADC_GetValue(&hadc1);

  if (HAL_ADC_Stop(&hadc1) != HAL_OK) { Error_Handler(); }
  return val;
}

static uint32_t ADC1_ReadTemp_Injected(void)
{
  if (HAL_ADCEx_InjectedStart(&hadc1) != HAL_OK) { Error_Handler(); }
  if (HAL_ADCEx_InjectedPollForConversion(&hadc1, 10) != HAL_OK) { Error_Handler(); }

  uint32_t val = HAL_ADCEx_InjectedGetValue(&hadc1, ADC_INJECTED_RANK_1);

  if (HAL_ADCEx_InjectedStop(&hadc1) != HAL_OK) { Error_Handler(); }
  return val;
}

static uint16_t tri_from_phase(uint32_t phase, uint32_t n_samples)
{
  const uint32_t half = n_samples / 2u;
  uint32_t val;

  if (phase < half)
  {
    val = (phase * 4095u) / (half - 1u);
  }
  else
  {
    val = ((n_samples - 1u - phase) * 4095u) / (half - 1u);
  }
  return (uint16_t)val;
}

/* Enable cycle counter for accurate microsecond delays */
static void DWT_Init(void)
{
  CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
  DWT->CYCCNT = 0;
  DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

static void DWT_Delay_us(uint32_t us)
{
  uint32_t cycles = (HAL_RCC_GetHCLKFreq() / 1000000u) * us;
  uint32_t start = DWT->CYCCNT;
  while ((DWT->CYCCNT - start) < cycles) { __NOP(); }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
